package com.example.minibrowserkeyboard

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import java.net.URLEncoder

class MiniBrowserIME : InputMethodService() {

    private var shift = false
    private var symbols = false
    private var urlFocus = false

    private lateinit var keysBox: LinearLayout
    private lateinit var browserPanel: LinearLayout
    private lateinit var urlBar: EditText
    private var webView: WebView? = null

    private val bg = Color.parseColor("#202124")
    private val keyBg = Color.parseColor("#3C4043")
    private val accent = Color.parseColor("#1A73E8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Prevent full-screen extract mode in landscape (it would hide the browser)
    override fun onEvaluateFullscreenMode() = false

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        // ---- Top toolbar ----
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolbar.addView(btn("🌐 Browser", 1f) { toggleBrowser() })
        toolbar.addView(btn("📋 Paste", 1f) { pasteClipboard() })
        toolbar.addView(btn("⌨ Switch", 1f) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        toolbar.addView(btn("⌄", 0.5f) { requestHideSelf(0) })
        root.addView(toolbar)

        // ---- Browser panel ----
        browserPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        navRow.addView(btn("◀", 0.4f) { webView?.goBack() })
        urlBar = EditText(this).apply {
            setSingleLine()
            hint = "Search or type URL"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            inputType = InputType.TYPE_NULL
            showSoftInputOnFocus = false
            setBackgroundColor(Color.parseColor("#303134"))
            setPadding(dp(8), 0, dp(8), 0)
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    urlFocus = true
                    v.requestFocus()
                    updateUrlBorder()
                }
                true
            }
        }
        navRow.addView(urlBar, LinearLayout.LayoutParams(0, dp(40), 3f))
        navRow.addView(btn("Go", 0.5f) { loadFromBar() })
        navRow.addView(btn("⤓ Sel", 0.6f) { insertSelection() })
        navRow.addView(btn("🔗", 0.4f) { webView?.url?.let { commit(it) } })
        browserPanel.addView(navRow)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
                override fun onPageFinished(v: WebView, url: String?) {
                    if (!urlFocus) urlBar.setText(url ?: "")
                }
            }
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_DOWN) { urlFocus = false; updateUrlBorder() }
                false
            }
            loadUrl("https://www.google.com")
        }
        browserPanel.addView(webView, LinearLayout.LayoutParams(-1, dp(230)))
        root.addView(browserPanel)

        // ---- Keys ----
        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysBox)
        buildKeys()
        return root
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }

    // ---------- Browser helpers ----------
    private fun toggleBrowser() {
        val show = browserPanel.visibility != View.VISIBLE
        browserPanel.visibility = if (show) View.VISIBLE else View.GONE
        urlFocus = false
        updateUrlBorder()
    }

    private fun updateUrlBorder() {
        urlBar.setBackgroundColor(if (urlFocus) Color.parseColor("#174EA6") else Color.parseColor("#303134"))
    }

    private fun loadFromBar() {
        val q = urlBar.text.toString().trim()
        if (q.isEmpty()) return
        val url = when {
            q.startsWith("http://") || q.startsWith("https://") -> q
            !q.contains(" ") && q.contains(".") -> "https://$q"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        }
        webView?.loadUrl(url)
        urlFocus = false
        updateUrlBorder()
    }

    private fun insertSelection() {
        webView?.evaluateJavascript("(function(){return window.getSelection().toString();})()") { raw ->
            val text = raw?.removeSurrounding("\"")
                ?.replace("\\n", "\n")?.replace("\\\"", "\"")?.replace("\\u003C", "<") ?: ""
            if (text.isNotEmpty() && text != "null") currentInputConnection?.commitText(text, 1)
        }
    }

    private fun pasteClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return
        commit(t)
    }

    // ---------- Typing ----------
    private fun commit(text: String) {
        if (browserPanel.visibility == View.VISIBLE && urlFocus) {
            urlBar.append(text)
        } else {
            currentInputConnection?.commitText(text, 1)
        }
    }

    private fun backspace() {
        if (browserPanel.visibility == View.VISIBLE && urlFocus) {
            val t = urlBar.text
            if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun enter() {
        if (browserPanel.visibility == View.VISIBLE && urlFocus) loadFromBar()
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    // ---------- Keyboard layout ----------
    private fun buildKeys() {
        keysBox.removeAllViews()
        val rows = if (symbols)
            listOf("1234567890", "@#$%&-+()/", "*\"':;!?")
        else
            listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

        rows.forEachIndexed { i, r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            if (i == 2 && !symbols) row.addView(btn(if (shift) "⬆" else "⇧", 1.4f) { shift = !shift; buildKeys() })
            if (i == 2 && symbols) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 0.4f))
            r.forEach { c ->
                val label = if (shift && !symbols) c.uppercaseChar().toString() else c.toString()
                row.addView(btn(label, 1f) {
                    commit(label)
                    if (shift) { shift = false; buildKeys() }
                })
            }
            if (i == 2) row.addView(btn("⌫", 1.4f) { backspace() })
            keysBox.addView(row)
        }

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(btn(if (symbols) "ABC" else "?123", 1.3f) { symbols = !symbols; buildKeys() })
        bottom.addView(btn(",", 0.8f) { commit(",") })
        bottom.addView(btn("space", 4f) { commit(" ") })
        bottom.addView(btn(".", 0.8f) { commit(".") })
        bottom.addView(btn("↵", 1.3f, accent) { enter() })
        keysBox.addView(bottom)
    }

    private fun btn(label: String, weight: Float, color: Int = keyBg, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT
            setBackgroundColor(color)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            setOnClickListener { onClick() }
        }
}
