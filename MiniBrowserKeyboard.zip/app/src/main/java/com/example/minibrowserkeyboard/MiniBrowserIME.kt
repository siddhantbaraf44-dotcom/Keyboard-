package com.example.minibrowserkeyboard

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class Item(val title: String, val sub: String, val img: String?, val share: String)

class MiniBrowserIME : InputMethodService() {

    companion object {
        const val TMDB_KEY = "d971d4b212180c43e0830d20c04a68b5"
        const val GIPHY_KEY = "aQxelph4YCx4BvBFUoNPKOUaoegKHyuW"
        const val TMDB_IMG = "https://image.tmdb.org/t/p/w185"
        const val KEYS = 0
        const val EMOJI = 1
        const val MEDIA = 2
        const val WEB = 3

        val WORDS: List<String> = ("the be to of and a in that have i it for not on with he as you do at this but his by " +
            "from they we say her she or an will my one all would there their what so up out if about who get which go me " +
            "when make can like time no just him know take people into year your good some could them see other than then " +
            "now look only come its over think also back after use two how our work first well way even new want because " +
            "any these give day most us is are was were been has had did said went thanks thank please hello hey hi okay " +
            "yes sorry love great nice awesome sure maybe today tomorrow tonight morning night evening home school office " +
            "friend friends family movie movies watch watching show series episode season anime song music game games " +
            "phone call message text send sent meet meeting where why what when which while right left really very much " +
            "more many little big long short late early soon never always sometimes still again already almost around " +
            "away down every everything everyone something someone nothing anything need needs needed feel feeling help " +
            "helping going gonna coming doing done tell told talk talking ask asked let lets try tried keep kept start " +
            "started stop wait waiting found find looking looks looked better best worse worst happy sad angry tired " +
            "hungry busy free ready available important interesting beautiful pretty cool fine perfect wonderful " +
            "definitely probably actually basically honestly anyway however because before between through during " +
            "without within against should shouldn't couldn't wouldn't don't can't won't didn't doesn't isn't it's i'm " +
            "i'll i've you're we're they're that's what's there's let's good-bye welcome congratulations birthday " +
            "weekend dinner lunch breakfast coffee water food eat drink").split(" ")

        val EMOJIS: LinkedHashMap<String, String> = linkedMapOf(
            "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤔 🤐 😐 😑 😶 😏 😒 🙄 😬 😮 😯 😲 😳 🥺 😢 😭 😤 😠 😡 🤬 🤯 😱 😨 😰 😥 😓 😴 😪 🤤 😷 🤒 🤕 🤢 🤮 🥵 🥶 😎 🤓 🥳 😈 👿 💀 👻 👽 🤖 💩",
            "👍" to "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖖 👋 🤝 🙏 ✍️ 💪 👏 🙌 👐 🤲 🫶 🫡 👀 👅 👄 🧠 👶 👦 👧 👨 👩 🧑 👴 👵",
            "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 💋 💯 💢 💥 💫 💦 💨 ✨ ⭐ 🌟 🔥 🎉 🎊 🎈 🎁 🏆 🥇 👑 💎 🔔 💤",
            "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦆 🦅 🦉 🦇 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🐬 🐳 🦈 🌸 🌹 🌻 🌳 🌍 🌙 ☀️ ⛅ 🌈 ❄️",
            "🍕" to "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🍞 🧀 🍳 🥞 🍔 🍟 🍕 🌭 🌮 🌯 🍣 🍜 🍝 🍩 🍪 🎂 🍰 🍫 🍬 🍭 🍿 ☕ 🍵 🍺 🍷 🥤 🍹",
            "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🎮 🎲 🎯 🎬 🎤 🎧 🎸 🎹 📱 💻 📷 📺 🔊 💡 📚 ✏️ 📌 🔒 🔑 🚗 ✈️ 🚀 ⏰ 💰 ✅ ❌ ❓ ❗ ⚡ 💬"
        )
    }

    // ---- palette (matches the dark reference keyboard) ----
    private val BG = Color.parseColor("#2B2B2D")
    private val KEY = Color.parseColor("#656567")
    private val SPECIAL = Color.parseColor("#4A4A4D")
    private val PILL = Color.parseColor("#505053")
    private val HINT = Color.parseColor("#A0A0A5")
    private val ICON = Color.parseColor("#D0D0D5")
    private val RED = Color.parseColor("#E50914")

    private var mode = KEYS
    private var shift = false
    private var symbols = false
    private var fieldFocus = false
    private var tab = 0
    private var reqId = 0
    private var curWordLen = 0
    private var webLoaded = false

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(4)
    private val cache = LruCache<String, Bitmap>(80)
    private val searchRun = Runnable { runSearch() }

    private lateinit var keysBox: LinearLayout
    private lateinit var mediaPanel: LinearLayout
    private lateinit var webPanel: LinearLayout
    private lateinit var emojiPanel: LinearLayout
    private lateinit var emojiGrid: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var resultScroll: HorizontalScrollView
    private lateinit var search: EditText
    private lateinit var urlBar: EditText
    private lateinit var emojiBtn: TextView
    private lateinit var mediaBtn: TextView
    private lateinit var webBtn: TextView
    private lateinit var sugg: Array<TextView>
    private lateinit var tabViews: List<TextView>
    private lateinit var emojiTabs: List<TextView>
    private var webView: WebView? = null

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat()
    }

    private fun lighter(c: Int) = Color.rgb(
        Color.red(c) + (255 - Color.red(c)) / 5,
        Color.green(c) + (255 - Color.green(c)) / 5,
        Color.blue(c) + (255 - Color.blue(c)) / 5
    )

    private fun pressable(c: Int, r: Int = 7) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), shape(lighter(c), r))
        addState(intArrayOf(), shape(c, r))
    }

    private fun label(
        txt: String, color: Int, size: Float = 18f, textColor: Int = Color.WHITE, onClick: (() -> Unit)? = null
    ): TextView = TextView(this).apply {
        text = txt
        gravity = Gravity.CENTER
        setTextColor(textColor)
        textSize = size
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = pressable(color)
        isClickable = true
        if (onClick != null) setOnClickListener { onClick() }
    }

    private fun lp(w: Float, h: Int = 44) = LinearLayout.LayoutParams(0, dp(h), w).apply {
        setMargins(dp(3), dp(3), dp(3), dp(3))
    }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), w) }

    private fun fieldBg(active: Boolean) = GradientDrawable().apply {
        setColor(PILL); cornerRadius = dp(18).toFloat()
        setStroke(dp(2), if (active) RED else Color.TRANSPARENT)
    }

    override fun onEvaluateFullscreenMode() = false

    // ---------- view creation ----------
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(3), dp(4), dp(3), dp(6))
        }
        root.addView(buildTopBar())
        mediaPanel = buildMediaPanel()
        webPanel = buildWebPanel()
        emojiPanel = buildEmojiPanel()
        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(mediaPanel)
        root.addView(webPanel)
        root.addView(emojiPanel)
        root.addView(keysBox)
        buildKeys()
        setMode(KEYS)
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::keysBox.isInitialized && !restarting) setMode(KEYS)
    }

    override fun onDestroy() {
        webView?.destroy(); webView = null
        io.shutdown()
        super.onDestroy()
    }

    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(PILL, 20)
            layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { setMargins(dp(3), dp(2), dp(3), dp(4)) }
        }
        fun icon(t: String, size: Float, click: () -> Unit) =
            label(t, PILL, size, ICON, click).apply {
                background = null
                layoutParams = LinearLayout.LayoutParams(dp(44), -1)
            }
        emojiBtn = icon("☺", 24f) { setMode(if (mode == EMOJI) KEYS else EMOJI) }
        mediaBtn = icon("🎬", 18f) { setMode(if (mode == MEDIA) KEYS else MEDIA) }
        webBtn = icon("🧭", 18f) { setMode(if (mode == WEB) KEYS else WEB) }
        bar.addView(emojiBtn)
        sugg = Array(3) { i ->
            TextView(this).apply {
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setHintTextColor(HINT)
                if (i == 1) hint = "Message…"
                textSize = 15f
                setSingleLine()
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { applySuggestion(i) }
            }
        }
        sugg.forEachIndexed { i, s ->
            if (i > 0) bar.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#7A7A7E"))
                layoutParams = LinearLayout.LayoutParams(dp(1), dp(18))
            })
            bar.addView(s)
        }
        bar.addView(mediaBtn)
        bar.addView(webBtn)
        return bar
    }

    // ---------- keyboard ----------
    private fun buildKeys() {
        keysBox.removeAllViews()
        val rows = if (symbols) listOf("1234567890", "-/:;()$&@\"", ".,?!'")
        else listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        rows.forEachIndexed { i, r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (i == 1 && !symbols) row.addView(spacer(0.5f))
            if (i == 2) {
                if (symbols) row.addView(spacer(1.5f))
                else row.addView(label(if (shift) "⬆" else "⇧", SPECIAL, 20f) { shift = !shift; buildKeys() }
                    .apply { layoutParams = lp(1.5f) })
            }
            r.forEach { c ->
                val l = if (shift && !symbols) c.uppercaseChar().toString() else c.toString()
                row.addView(label(l, KEY, 20f) {
                    commit(l)
                    if (shift) { shift = false; buildKeys() }
                }.apply { layoutParams = lp(1f) })
            }
            if (i == 2) row.addView(backspaceKey().apply { layoutParams = lp(1.5f) })
            if (i == 1 && !symbols) row.addView(spacer(0.5f))
            keysBox.addView(row)
        }
        val b = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        b.addView(label(if (symbols) "ABC" else "123", SPECIAL, 14f) { symbols = !symbols; buildKeys() }
            .apply { layoutParams = lp(1.4f) })
        b.addView(label("🌐", SPECIAL, 18f) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }.apply { layoutParams = lp(1.2f) })
        b.addView(label("space", KEY, 14f, HINT) { commit(" ") }.apply { layoutParams = lp(5f) })
        b.addView(label("return", SPECIAL, 14f) { enter() }.apply { layoutParams = lp(2f) })
        keysBox.addView(b)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun backspaceKey(): TextView {
        val rep = object : Runnable {
            override fun run() { backspace(); main.postDelayed(this, 60) }
        }
        return label("⌫", SPECIAL, 18f).apply {
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { isPressed = true; backspace(); main.postDelayed(rep, 400) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { isPressed = false; main.removeCallbacks(rep) }
                }
                true
            }
        }
    }

    // ---------- typing ----------
    private fun field(): EditText? = if (!fieldFocus) null else when (mode) {
        MEDIA -> search
        WEB -> urlBar
        else -> null
    }

    private fun commit(t: String) {
        val f = field()
        if (f != null) f.append(t) else commitApp(t)
    }

    private fun commitApp(t: String) {
        currentInputConnection?.commitText(t, 1)
        updateSuggestions()
    }

    private fun backspace() {
        val f = field()
        if (f != null) {
            val t = f.text
            if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            main.post { updateSuggestions() }
        }
    }

    private fun enter() {
        val f = field()
        if (f === search) { main.removeCallbacks(searchRun); runSearch(); return }
        if (f === urlBar) { loadFromBar(); return }
        val ei = currentInputEditorInfo
        val a = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED
        ) currentInputConnection?.performEditorAction(a)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    // ---------- suggestions ----------
    private fun updateSuggestions() {
        if (!::sugg.isInitialized) return
        var list: List<String> = emptyList()
        curWordLen = 0
        if (field() == null && mode != EMOJI) {
            val before = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString().orEmpty()
            val w = before.takeLastWhile { it.isLetter() || it == '\'' }
            curWordLen = w.length
            list = if (w.isEmpty()) {
                val end = before.trimEnd().lastOrNull()
                if (before.isBlank() || end == '.' || end == '!' || end == '?') listOf("I", "The", "Hello")
                else listOf("I", "the", "and")
            } else {
                val lw = w.lowercase()
                val m = WORDS.filter { it.startsWith(lw) && it != lw }.take(3).map {
                    if (w[0].isUpperCase()) it.replaceFirstChar { c -> c.uppercase() } else it
                }
                (listOf(w) + m).distinct().take(3)
            }
        }
        sugg.forEachIndexed { i, s -> s.text = list.getOrElse(i) { "" } }
    }

    private fun applySuggestion(i: Int) {
        val s = sugg[i].text.toString()
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        if (curWordLen > 0) ic.deleteSurroundingText(curWordLen, 0)
        ic.commitText("$s ", 1)
        updateSuggestions()
    }

    // ---------- modes ----------
    private fun setMode(m: Int) {
        mode = m
        fieldFocus = (m == MEDIA || m == WEB)
        emojiPanel.visibility = if (m == EMOJI) View.VISIBLE else View.GONE
        keysBox.visibility = if (m == EMOJI) View.GONE else View.VISIBLE
        mediaPanel.visibility = if (m == MEDIA) View.VISIBLE else View.GONE
        webPanel.visibility = if (m == WEB) View.VISIBLE else View.GONE
        emojiBtn.setTextColor(if (m == EMOJI) RED else ICON)
        mediaBtn.alpha = if (m == MEDIA) 1f else 0.7f
        webBtn.alpha = if (m == WEB) 1f else 0.7f
        if (m == MEDIA && results.childCount == 0) selectTab(tab)
        if (m == WEB && !webLoaded) { webLoaded = true; webView?.loadUrl("https://www.google.com") }
        highlight()
        updateSuggestions()
    }

    private fun highlight() {
        search.background = fieldBg(fieldFocus && mode == MEDIA)
        urlBar.background = fieldBg(fieldFocus && mode == WEB)
    }

    // ---------- emoji ----------
    private fun buildEmojiPanel(): LinearLayout {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        emojiTabs = EMOJIS.keys.mapIndexed { i, k ->
            label(k, SPECIAL, 18f) { showEmojiCat(i) }.apply { layoutParams = lp(1f, 38) }
        }
        emojiTabs.forEach { tabs.addView(it) }
        p.addView(tabs)
        emojiGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(ScrollView(this).apply {
            addView(emojiGrid)
            layoutParams = LinearLayout.LayoutParams(-1, dp(136))
        })
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(label("ABC", SPECIAL, 14f) { setMode(KEYS) }.apply { layoutParams = lp(1.5f) })
        bottom.addView(spacer(5f))
        bottom.addView(backspaceKey().apply { layoutParams = lp(1.5f) })
        p.addView(bottom)
        showEmojiCat(0)
        return p
    }

    private fun showEmojiCat(i: Int) {
        emojiTabs.forEachIndexed { j, t -> t.background = pressable(if (j == i) KEY else SPECIAL) }
        emojiGrid.removeAllViews()
        EMOJIS.values.elementAt(i).split(" ").chunked(8).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { e ->
                row.addView(TextView(this).apply {
                    text = e; textSize = 24f; gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
                    setOnClickListener { commitApp(e) }
                })
            }
            repeat(8 - chunk.size) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(42), 1f)) }
            emojiGrid.addView(row)
        }
    }

    // ---------- Movies / TV / Anime / GIFs ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun buildMediaPanel(): LinearLayout {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        search = EditText(this).apply {
            setSingleLine()
            hint = "Search movies, TV, anime, GIFs"
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 14f
            inputType = InputType.TYPE_NULL
            isFocusable = false
            isFocusableInTouchMode = false
            background = fieldBg(false)
            setPadding(dp(16), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(38)).apply { setMargins(dp(3), dp(2), dp(3), dp(3)) }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) { fieldFocus = true; highlight(); updateSuggestions() }
                true
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    main.removeCallbacks(searchRun); main.postDelayed(searchRun, 450)
                }
            })
        }
        p.addView(search)
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabViews = listOf("Movies", "TV", "Anime", "GIFs").mapIndexed { i, n ->
            label(n, SPECIAL, 13f) { selectTab(i) }.apply { layoutParams = lp(1f, 32) }
        }
        tabViews.forEach { tabRow.addView(it) }
        p.addView(tabRow)
        results = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(3), dp(2), dp(3), dp(2)) }
        resultScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(results)
            layoutParams = LinearLayout.LayoutParams(-1, dp(150))
        }
        p.addView(resultScroll)
        return p
    }

    private fun selectTab(i: Int) {
        tab = i
        tabViews.forEachIndexed { j, t -> t.background = pressable(if (j == i) RED else SPECIAL) }
        runSearch()
    }

    private fun runSearch() {
        val q = search.text.toString().trim()
        val id = ++reqId
        val t = tab
        showStatus("Loading…")
        io.execute {
            val items = try { fetch(t, q) } catch (e: Exception) { null }
            main.post {
                if (id == reqId) {
                    when {
                        items == null -> showStatus("Couldn't load. Check your connection.")
                        items.isEmpty() -> showStatus("No results")
                        else -> showItems(items, t == 3)
                    }
                }
            }
        }
    }

    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun fetch(t: Int, q: String): List<Item> {
        val enc = URLEncoder.encode(q, "UTF-8")
        if (t == 3) {
            val u = if (q.isEmpty()) "https://api.giphy.com/v1/gifs/trending?api_key=$GIPHY_KEY&limit=24&rating=pg-13"
            else "https://api.giphy.com/v1/gifs/search?api_key=$GIPHY_KEY&q=$enc&limit=24&rating=pg-13"
            val arr = JSONObject(http(u)).getJSONArray("data")
            return (0 until arr.length()).map { n ->
                val o = arr.getJSONObject(n)
                val im = o.getJSONObject("images")
                val still = (im.optJSONObject("fixed_width_small_still") ?: im.optJSONObject("fixed_width_still"))?.optString("url")
                Item("", "", still, o.getString("url"))
            }
        }
        val base = "https://api.themoviedb.org/3"
        val kind = if (t == 0) "movie" else "tv"
        val u = when {
            q.isNotEmpty() -> "$base/search/$kind?api_key=$TMDB_KEY&query=$enc&include_adult=false"
            t == 2 -> "$base/discover/tv?api_key=$TMDB_KEY&with_genres=16&with_original_language=ja&sort_by=popularity.desc"
            else -> "$base/trending/$kind/week?api_key=$TMDB_KEY"
        }
        val arr = JSONObject(http(u)).getJSONArray("results")
        var list = (0 until arr.length()).map { arr.getJSONObject(it) }
        if (t == 2 && q.isNotEmpty()) {
            val f = list.filter { o ->
                val g = o.optJSONArray("genre_ids")
                g != null && (0 until g.length()).any { k -> g.getInt(k) == 16 }
            }
            if (f.isNotEmpty()) list = f
        }
        val icon = when (t) { 0 -> "🎬"; 1 -> "📺"; else -> "🍥" }
        return list.map { o ->
            val title = o.optString(if (t == 0) "title" else "name")
            val year = o.optString(if (t == 0) "release_date" else "first_air_date").take(4)
            val rating = o.optDouble("vote_average", 0.0)
            val poster = o.optString("poster_path", "")
            val star = if (rating > 0) " ⭐ " + "%.1f".format(rating) else ""
            Item(
                title, (year + star).trim(),
                if (poster.isNotEmpty() && poster != "null") TMDB_IMG + poster else null,
                "$icon $title" + (if (year.isNotEmpty()) " ($year)" else "") + star +
                    "\nhttps://www.themoviedb.org/$kind/${o.getInt("id")}"
            )
        }
    }

    private fun showStatus(msg: String) {
        results.removeAllViews()
        results.addView(TextView(this).apply {
            text = msg; setTextColor(HINT); textSize = 14f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(resources.displayMetrics.widthPixels - dp(12), dp(140))
        })
    }

    private fun showItems(items: List<Item>, gif: Boolean) {
        results.removeAllViews()
        resultScroll.scrollTo(0, 0)
        items.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(dp(if (gif) 112 else 78), -2).apply { setMargins(dp(3), 0, dp(3), 0) }
                setOnClickListener { share(item, this) }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = shape(SPECIAL, 8)
                clipToOutline = true
                layoutParams = LinearLayout.LayoutParams(-1, dp(if (gif) 96 else 112))
            }
            card.addView(iv)
            if (!gif) {
                card.addView(TextView(this).apply {
                    text = item.title; setTextColor(Color.WHITE); textSize = 11f
                    setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                })
                card.addView(TextView(this).apply {
                    text = item.sub; setTextColor(HINT); textSize = 10f; setSingleLine()
                })
            }
            item.img?.let { loadImage(it, iv) }
            results.addView(card)
        }
    }

    private fun share(item: Item, card: View) {
        currentInputConnection?.commitText(item.share, 1)
        fieldFocus = false
        highlight()
        updateSuggestions()
        card.alpha = 0.4f
        card.postDelayed({ card.alpha = 1f }, 350)
    }

    private fun loadImage(url: String, iv: ImageView) {
        iv.tag = url
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        io.execute {
            try {
                val bmp = BitmapFactory.decodeStream(URL(url).openStream())
                if (bmp != null) {
                    cache.put(url, bmp)
                    main.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) { }
        }
    }

    // ---------- mini browser ----------
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun buildWebPanel(): LinearLayout {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(label("◀", SPECIAL, 14f) { webView?.goBack() }.apply { layoutParams = lp(0.5f, 38) })
        urlBar = EditText(this).apply {
            setSingleLine()
            hint = "Search or type URL"
            setHintTextColor(HINT)
            setTextColor(Color.WHITE)
            textSize = 14f
            inputType = InputType.TYPE_NULL
            isFocusable = false
            isFocusableInTouchMode = false
            background = fieldBg(false)
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = lp(3f, 38)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) { fieldFocus = true; highlight(); updateSuggestions() }
                true
            }
        }
        nav.addView(urlBar)
        nav.addView(label("Go", RED, 13f) { loadFromBar() }.apply { layoutParams = lp(0.6f, 38) })
        nav.addView(label("⤓ Sel", SPECIAL, 12f) { insertSelection() }.apply { layoutParams = lp(0.8f, 38) })
        nav.addView(label("🔗", SPECIAL, 14f) { webView?.url?.let { commitApp(it) } }.apply { layoutParams = lp(0.5f, 38) })
        p.addView(nav)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
                override fun onPageFinished(v: WebView, url: String?) {
                    if (!fieldFocus) urlBar.setText(url ?: "")
                }
            }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) { fieldFocus = false; highlight(); updateSuggestions() }
                false
            }
            layoutParams = LinearLayout.LayoutParams(-1, dp(170))
        }
        p.addView(webView)
        return p
    }

    private fun loadFromBar() {
        val q = urlBar.text.toString().trim()
        if (q.isEmpty()) return
        val url = when {
            q.startsWith("http://") || q.startsWith("https://") -> q
            !q.contains(" ") && q.contains(".") -> "https://$q"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        }
        webView?.loadUrl(url)
        fieldFocus = false
        highlight()
        updateSuggestions()
    }

    private fun insertSelection() {
        webView?.evaluateJavascript("(function(){return window.getSelection().toString();})()") { raw ->
            val text = raw?.removeSurrounding("\"")
                ?.replace("\\n", "\n")?.replace("\\\"", "\"")?.replace("\\u003C", "<") ?: ""
            if (text.isNotEmpty() && text != "null") commitApp(text)
        }
    }
}
