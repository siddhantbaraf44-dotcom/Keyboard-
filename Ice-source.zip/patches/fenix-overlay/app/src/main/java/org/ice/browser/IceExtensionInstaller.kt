/* Ice: install a Firefox extension from a pasted link. License: MPL-2.0 */
package org.ice.browser

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.mozilla.fenix.ext.components

object IceExtensionInstaller {
    /** Page that opens the dialog when typed in the address bar. */
    const val TRIGGER = "about:ice-extension"

    private val AMO_PAGE = Regex(
        "^https://addons\\.mozilla\\.org/[^/]+/(?:firefox|android)/addon/([^/?#]+)/?.*$",
        RegexOption.IGNORE_CASE,
    )

    /** Turns an AMO page link or a direct .xpi link into a downloadable .xpi URL, or null. */
    fun resolve(input: String): String? {
        val link = input.trim()
        if (!link.startsWith("https://", ignoreCase = true)) return null
        AMO_PAGE.matchEntire(link)?.let {
            return "https://addons.mozilla.org/firefox/downloads/latest/${it.groupValues[1]}/latest.xpi"
        }
        return if (link.substringBefore('?').substringBefore('#').endsWith(".xpi", true)) link else null
    }

    private fun Context.activity(): Activity? {
        var c: Context? = this
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }

    fun show(context: Context) {
        val activity = context.activity() ?: return
        val input = EditText(activity).apply {
            hint = "https://addons.mozilla.org/.../addon/ublock-origin/  or  https://.../file.xpi"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(false)
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(activity)
            .setTitle("Add extension from link")
            .setMessage("Paste a Firefox Add-ons page link or a direct .xpi link.")
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton("Install") { _, _ -> install(activity, input.text.toString()) }
            .show()
    }

    private fun install(activity: Activity, text: String) {
        val xpi = resolve(text)
        if (xpi == null) {
            Toast.makeText(activity, "Enter a valid https extension link", Toast.LENGTH_LONG).show()
            return
        }
        activity.components.core.engine.installWebExtension(
            url = xpi,
            onSuccess = { ext ->
                activity.runOnUiThread {
                    Toast.makeText(activity, "Installed ${ext.id}", Toast.LENGTH_LONG).show()
                }
            },
            onError = { _, throwable ->
                activity.runOnUiThread {
                    Toast.makeText(activity, "Install failed: ${throwable.message}", Toast.LENGTH_LONG).show()
                }
            },
        )
    }
}
