package org.ironfoxoss.ironfox.utils

import android.content.Context
import android.os.Build
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import org.ironfoxoss.core.IFDeviceUtils
import org.ironfoxoss.ironfox.utils.IronFoxPreferences
import org.mozilla.fenix.R
import org.mozilla.fenix.ext.getPreferenceKey

// Helpers for controlling the visibility of Fenix UI settings

object FenixSettingsVisibilityManager {
  /**
   * Control the visibility of settings at the general settings fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun SettingsFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val isTV: Boolean = IFDeviceUtils.isTV(context)

    hidePreference(context, R.string.pref_key_data_choices, prefFragment)
    hidePreference(context, R.string.pref_key_firefox_labs, prefFragment)
    hidePreference(context, R.string.pref_key_link_sharing, prefFragment)
    hidePreference(context, R.string.pref_key_nimbus_experiments, prefFragment)
    hidePreference(context, R.string.pref_key_remote_improvements, prefFragment)
    hidePreference(context, R.string.pref_key_rate, prefFragment)
    hidePreference(context, R.string.pref_key_start_profiler, prefFragment)
    hidePreference(context, R.string.pref_key_remote_debugging, prefFragment)
    hideFxa(context, prefFragment)
    hideLocalAddonInstall(context, prefFragment)

    if (isTV) {
      // Hide the no-op Notifications setting
      hidePreference(context, R.string.pref_key_notifications, prefFragment)
    }
  }

  /**
   * Control the visibility of settings at the secret settings fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun SecretSettingsFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    displayPreference(context, R.string.pref_key_debug_force_weekly_privacy_report_notification, prefFragment)
    displayPreference(context, R.string.pref_key_enable_homepage_as_new_tab, prefFragment)
    displayPreference(context, R.string.pref_key_enable_import_bookmarks, prefFragment)
    displayPreference(context, R.string.pref_key_enable_import_passwords, prefFragment)
    displayPreference(context, R.string.pref_key_enable_isolated_process, prefFragment)
    displayPreference(context, R.string.pref_key_enable_lna_blocking_enabled, prefFragment)
    displayPreference(context, R.string.pref_key_enable_lna_feature_enabled, prefFragment)
    displayPreference(context, R.string.pref_key_enable_lna_tracker_blocking_enabled, prefFragment)
    displayPreference(context, R.string.pref_key_enable_wayback_machine, prefFragment)
    displayPreference(context, R.string.pref_key_enable_weekly_privacy_notification, prefFragment)
    displayPreference(context, R.string.pref_key_native_share_sheet, prefFragment)
    displayPreference(context, R.string.pref_key_should_show_custom_tab_extensions, prefFragment)
    displayPreference(context, R.string.pref_key_show_tab_groups_in_menu, prefFragment)
    displayPreference(context, R.string.pref_key_tab_groups, prefFragment)
    displayPreference(context, R.string.pref_key_tab_groups_drag_and_drop, prefFragment)
    displayPreference(context, R.string.pref_key_tab_groups_live_reorder, prefFragment)
    displayPreference(context, R.string.pref_key_tab_groups_strip, prefFragment)
    displayPreference(context, R.string.pref_key_toolbar_focus_mode, prefFragment)
    displayPreference(context, R.string.pref_key_use_minimal_bottom_toolbar_while_entering_text, prefFragment)
    displayPreference(context, R.string.pref_key_use_scroll_data_for_dynamic_toolbar, prefFragment)
    displayAddressSync(context, prefFragment)
    displayAppZygote(context, prefFragment)

    hidePreference(context, R.string.pref_key_crash_pull_never_show_again, prefFragment)
    hidePreference(context, R.string.pref_key_enable_ads_client_for_stories, prefFragment)
    hidePreference(context, R.string.pref_key_enable_uninstall_survey, prefFragment)
    hidePreference(context, R.string.pref_key_microsurvey_feature_enabled, prefFragment)
    hidePreference(context, R.string.pref_key_nimbus_use_preview, prefFragment)
    hidePreference(context, R.string.pref_key_private_mode_and_stories_entry_point, prefFragment)
    hidePreference(context, R.string.pref_key_use_new_crash_reporter, prefFragment)
    hidePreference(context, R.string.pref_key_use_remote_search_configuration, prefFragment)
  }

  /**
   * Control the visibility of settings at the customization settings fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun CustomizationSettingsFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    hideTVSettings(context, prefFragment)
  }

  /**
   * Control the visibility of settings at the site settings fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun SiteSettingsFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    hideEme(context, prefFragment)
  }

  /**
   * Control the visibility of settings at the search settings fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun SearchSettingsFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    hidePreference(context, R.string.pref_key_show_sponsored_suggestions, prefFragment)
    hidePreference(context, R.string.pref_key_show_voice_search, prefFragment)
    hideSyncedTabsSuggestions(context, prefFragment)
  }

  /**
   * Control the visibility of settings at the tracking protection fragment
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  fun TrackingProtectionFragment(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    hidePreference(context, R.string.pref_key_privacy_enable_global_privacy_control, prefFragment)
    hidePreference(context, R.string.pref_key_tracking_protection, prefFragment)
    hidePreference(context, R.string.pref_key_tracking_protection_custom_option, prefFragment)
    hidePreference(context, R.string.pref_key_tracking_protection_standard_option, prefFragment)
    hidePreference(context, R.string.pref_key_tracking_protection_strict_default, prefFragment)
  }

  /**
   * Display the setting to enable Firefox address sync
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun displayAddressSync(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val addressSyncKey = context.getPreferenceKey(R.string.pref_key_enable_address_sync)
    val addressSyncPreference = prefFragment.findPreference<Preference>(addressSyncKey)

    if (!IronFoxPreferences.isFxaEnabled(context)) {
      addressSyncPreference?.isVisible = false
    }
  }

  /**
   * Display the setting to toggle app zygote preloading
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun displayAppZygote(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val appZygoteKey = context.getPreferenceKey(R.string.pref_key_enable_app_zygote_process)
    val appZygotePreference = prefFragment.findPreference<Preference>(appZygoteKey)
    appZygotePreference?.isVisible = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
  }

  /**
   * Hide the EME site setting
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun hideEme(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val emeSiteSettingKey = context.getPreferenceKey(R.string.pref_key_browser_feature_media_key_system_access)
    val emeSiteSettingPreference = prefFragment.findPreference<Preference>(emeSiteSettingKey)

    if (!IronFoxPreferences.isEMEEnabled(context)) {
      emeSiteSettingPreference?.isVisible = false
    }
  }

  /**
   * Hide Firefox Sync settings
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun hideFxa(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val fxaAccountCategoryKey = context.getPreferenceKey(R.string.pref_key_account_category)
    val fxaDebugKey = context.getPreferenceKey(R.string.pref_key_sync_debug)
    val fxaSignInKey = context.getPreferenceKey(R.string.pref_key_sign_in)

    val fxaAccountCategoryPreference = prefFragment.findPreference<Preference>(fxaAccountCategoryKey)
    val fxaDebugPreference = prefFragment.findPreference<Preference>(fxaDebugKey)
    val fxaSignInPreference = prefFragment.findPreference<Preference>(fxaSignInKey)

    if (!IronFoxPreferences.isFxaEnabled(context)) {
      fxaAccountCategoryPreference?.isVisible = false
      fxaDebugPreference?.isVisible = false
      fxaSignInPreference?.isVisible = false
    }
  }

  /**
   * Hide settings for TV users
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun hideTVSettings(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val isTV: Boolean = IFDeviceUtils.isTV(context)

    val appIconCatKey = context.getPreferenceKey(R.string.pref_key_customization_category_app_icon)
    val appIconKey = context.getPreferenceKey(R.string.pref_key_app_icon)
    val dynamicToolbarKey = context.getPreferenceKey(R.string.pref_key_dynamic_toolbar)
    val pullToRefreshKey = context.getPreferenceKey(R.string.pref_key_website_pull_to_refresh)
    val swipeShowTabsKey = context.getPreferenceKey(R.string.pref_key_swipe_toolbar_show_tabs)
    val swipeSwitchTabsKey = context.getPreferenceKey(R.string.pref_key_swipe_toolbar_switch_tabs)

    val appIconCatPreference = prefFragment.findPreference<Preference>(appIconCatKey)
    val appIconPreference = prefFragment.findPreference<Preference>(appIconKey)
    val dynamicToolbarPreference = prefFragment.findPreference<Preference>(dynamicToolbarKey)
    val pullToRefreshPreference = prefFragment.findPreference<Preference>(pullToRefreshKey)
    val swipeShowTabsPreference = prefFragment.findPreference<Preference>(swipeShowTabsKey)
    val swipeSwitchTabsPreference = prefFragment.findPreference<Preference>(swipeSwitchTabsKey)

    if (isTV) {
      appIconCatPreference?.isVisible = false
      appIconPreference?.isVisible = false
      dynamicToolbarPreference?.isVisible = false
      pullToRefreshPreference?.isVisible = false
      swipeShowTabsPreference?.isVisible = false
      swipeSwitchTabsPreference?.isVisible = false
    }
  }

  /**
   * Hide the local add-on installation option
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun hideLocalAddonInstall(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val localAddonInstallKey = context.getPreferenceKey(R.string.pref_key_install_local_addon)
    val localAddonInstallPreference = prefFragment.findPreference<Preference>(localAddonInstallKey)

    if (!IronFoxPreferences.isXPInstallEnabled(context)) {
      localAddonInstallPreference?.isVisible = false
    }
  }

  /**
   * Hide the option to enable synced tab suggestions
   *
   * @param context Application context
   * @param prefFragment Preference fragment
   */
  internal fun hideSyncedTabsSuggestions(
    context: Context,
    prefFragment: PreferenceFragmentCompat
  ) {
    val syncedTabSuggestionsKey = context.getPreferenceKey(R.string.pref_key_search_synced_tabs)
    val syncedTabSuggestionsPreference = prefFragment.findPreference<Preference>(syncedTabSuggestionsKey)

    if (!IronFoxPreferences.isFxaEnabled(context) && !IronFoxPreferences.isFxaSignedIn(context)) {
      syncedTabSuggestionsPreference?.isVisible = false
    }
  }

  /**
   * Display a hidden UI setting
   *
   * @param context Application context
   * @param pref Preference to display
   * @param prefFragment Preference fragment
   */
  internal fun displayPreference(
    context: Context,
    pref: Int,
    prefFragment: PreferenceFragmentCompat,
  ) {
    val prefKey = context.getPreferenceKey(pref)
    val preference = prefFragment.findPreference<Preference>(prefKey)
    preference?.isVisible = true
  }

  /**
   * Hide an unwanted UI setting
   *
   * @param context Application context
   * @param pref Preference to remove
   * @param prefFragment Preference fragment
   */
  internal fun hidePreference(
    context: Context,
    pref: Int,
    prefFragment: PreferenceFragmentCompat,
  ) {
    val prefKey = context.getPreferenceKey(pref)
    val preference = prefFragment.findPreference<Preference>(prefKey)
    preference?.isVisible = false
  }
}
