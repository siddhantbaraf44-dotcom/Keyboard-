# Ice changes (on top of IronFox)
1. **Rebrand**: app name "Ice" / "Ice Nightly", new snowflake logo, launcher/round/monochrome icons, wordmark, about logo.
   Package ID is unchanged (org.ironfoxoss.*) to avoid breaking the patch set.
2. **Sticky full screen**: Back button/gesture no longer exits full screen; only the page's full-screen toggle does.
   (scripts/ice_customize.py edits FullScreenFeature.onBackPressed; the build fails loudly if upstream code changed.)
3. **Install extension from link**: type `about:ice-extension` in the address bar, paste an addons.mozilla.org page link
   or a direct .xpi https link. (patches/fenix-overlay/.../org/ice/browser/IceExtensionInstaller.kt)
4. **GitHub Actions**: .github/workflows/build.yml
