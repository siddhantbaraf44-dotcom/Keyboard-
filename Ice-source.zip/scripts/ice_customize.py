#!/usr/bin/env python3
"""Ice customizations applied to the Firefox/Fenix source tree during prebuild.

1. Full screen is sticky: the Back button/gesture no longer exits full screen.
2. Typing `about:ice-extension` in the address bar opens an "add extension from link" dialog.

Every edit is anchor-checked: if upstream code changed and an anchor is missing, the build
FAILS with a clear message instead of silently shipping without the feature.
"""
import re
import sys
from pathlib import Path

fenix, ac = Path(sys.argv[1]), Path(sys.argv[2])


def fail(msg):
    print(f"ICE ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def span_of_function(src, signature):
    """Return (start, end) of a Kotlin function body via brace matching."""
    i = src.find(signature)
    if i < 0:
        return None
    j = src.find("{", i)
    depth = 0
    for k in range(j, len(src)):
        depth += src[k] == "{"
        depth -= src[k] == "}"
        if depth == 0:
            return i, k + 1
    return None


# ---- 1. sticky full screen -------------------------------------------------
fs = list(ac.rglob("FullScreenFeature.kt"))
if not fs:
    fail("FullScreenFeature.kt not found")
f = fs[0]
src = f.read_text()
span = span_of_function(src, "override fun onBackPressed(): Boolean")
if not span:
    fail("FullScreenFeature.onBackPressed not found")
body = src[span[0]:span[1]]
new_body, n = re.subn(r"^[ \t]*[\w.]*[eE]xit[Ff]ull[Ss]creen\([^\n]*\)[ \t]*\n", "", body, flags=re.M)
if n == 0:
    fail("no exitFullscreen call inside onBackPressed; upstream changed, update ice_customize.py")
# `true` is still returned while in full screen, so Back is consumed and nothing else reacts.
f.write_text(src[:span[0]] + new_body + src[span[1]:])
print(f"ice: sticky full screen applied to {f} ({n} call removed)")

# ---- 2. extension-from-link entry point -----------------------------------
mw = next(fenix.rglob("BrowserToolbarSearchMiddleware.kt"), None)
if not mw:
    fail("BrowserToolbarSearchMiddleware.kt not found")
s = mw.read_text()
anchor = re.search(r"\n([ \t]*)else ->\n[ \t]*if \(url\.isNotBlank\(\)\) \{", s)
if not anchor:
    fail("address-bar `else ->` anchor not found; upstream changed, update ice_customize.py")
ind = anchor.group(1)
inject = (f'\n{ind}org.ice.browser.IceExtensionInstaller.TRIGGER ->\n'
          f'{ind}    org.ice.browser.IceExtensionInstaller.show(navController.context)')
s = s[:anchor.start()] + inject + s[anchor.start():]
mw.write_text(s)
print("ice: extension-from-link entry added")
