#!/bin/bash

# Script is used to update the F-Droid repository
# This script is expected to be run in a CI environment
# DO NOT execute this manually!

set -euo pipefail

# Ensure this is never ran with xtrace...
set +x || exit 1

# Set-up our environment
function setup_env() {
  if [[ -z "${IRONFOX_SET_ENVS+x}" ]] || [[ "${IRONFOX_SET_ENVS}" != 1 ]]; then
    # Find dirname
    if [[ -n "${IRONFOX_DIRNAME+x}" ]] && [[ -x "${IRONFOX_DIRNAME}" ]]; then
      local -r dirname="${IRONFOX_DIRNAME}"
    elif [[ -x '/bin/dirname' ]]; then
      local -r dirname='/bin/dirname'
    elif [[ -x '/usr/bin/dirname' ]]; then
      local -r dirname='/usr/bin/dirname'
    else
      if ! command -v dirname > /dev/null 2>&1; then
        echo "ERROR: Missing dirname!" >&2
        return 1
      fi
      # It isn't a known location, so we sadly have to just fall-back to the PATH
      local -r dirname="$(dirname)"
    fi

    # Set-up our environment
    readonly IRONFOX_ENV_SH="$("${dirname}" $0)/env.sh"
    if [[ ! -f "${IRONFOX_ENV_SH}" ]] || [[ ! -s "${IRONFOX_ENV_SH}" ]]; then
      echo "ERROR: '${IRONFOX_ENV_SH}' is invalid!"
      return 1
    fi
    source "${IRONFOX_ENV_SH}" || return 1
  fi
}

# Set-up our environment
setup_env || exit 1

# Include download utilities
verify_file_with_env "${IRONFOX_DOWNLOAD_UTILS}" 'IRONFOX_DOWNLOAD_UTILS' || exit 1
source "${IRONFOX_DOWNLOAD_UTILS}" || exit 1

# Ensure we have `IRONFOX_CI`
verify_env "${IRONFOX_CI}" 'IRONFOX_CI' || exit 1

if [[ "${IRONFOX_CI}" != 1 ]]; then
  echo_red_text "ERROR: '$0' should only be called from CI!"
  exit 1
fi

# Ensure we have basename
verify_exec "${IRONFOX_BASENAME}" 'IRONFOX_BASENAME' || exit 1

# Ensure we have cat
verify_exec "${IRONFOX_CAT}" 'IRONFOX_CAT' || exit 1

# Ensure we have git
verify_exec "${IRONFOX_GIT}" 'IRONFOX_GIT' || exit 1

# Ensure we have git-lfs
verify_exec "${IRONFOX_GIT_LFS}" 'IRONFOX_GIT_LFS' || exit 1

# Ensure we have GNU sed
verify_exec "${IRONFOX_SED}" 'IRONFOX_SED' || exit 1

# Ensure we have ls
verify_exec "${IRONFOX_LS}" 'IRONFOX_LS' || exit 1

# Ensure we have mkdir
verify_exec "${IRONFOX_MKDIR}" 'IRONFOX_MKDIR' || exit 1

# Ensure we have Python
verify_exec "${IRONFOX_PYTHON}" 'IRONFOX_PYTHON' || exit 1

# Ensure we have rm
verify_exec "${IRONFOX_RM}" 'IRONFOX_RM' || exit 1

# Ensure we have touch
verify_exec "${IRONFOX_TOUCH}" 'IRONFOX_TOUCH' || exit 1

# Ensure we have xargs
verify_exec "${IRONFOX_XARGS}" 'IRONFOX_XARGS' || exit 1

# Ensure we have `IRONFOX_EXTERNAL`
verify_env "${IRONFOX_EXTERNAL}" 'IRONFOX_EXTERNAL' || exit 1

# Ensure we have `IRONFOX_TEMP`
verify_env "${IRONFOX_TEMP}" 'IRONFOX_TEMP' || exit 1

# Ensure we have `IRONFOX_VERSION`
verify_env "${IRONFOX_VERSION}" 'IRONFOX_VERSION' || exit 1

# Ensure we have `IRONFOX_SCRIPTS`
verify_dir_with_env "${IRONFOX_SCRIPTS}" 'IRONFOX_SCRIPTS' || exit 1

# Ensure we can source our Python environment
verify_file_with_env "${IRONFOX_PYENV}" 'IRONFOX_PYENV' || exit 1

# Constants

# Base releases URL
readonly IRONFOX_RELEASES_BASE_URL="https://releases.ironfoxoss.org/ironfox"

# Target S3 path
if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
  readonly IRONFOX_RELEASES_S3_PATH='releases'
else
  readonly IRONFOX_RELEASES_S3_PATH='nightly'
fi

readonly IRONFOX_RELEASES_TARGET_URL="${IRONFOX_RELEASES_BASE_URL}/${IRONFOX_RELEASES_S3_PATH}"

# fdroid repo
readonly IRONFOX_FDROID_REPO_ROOT="${IRONFOX_EXTERNAL}/fdroid"
readonly IRONFOX_FDROID_REPO="${IRONFOX_FDROID_REPO_ROOT}/fdroid/repo"
readonly IRONFOX_FDROID_REPO_BRANCH='dev'
readonly IRONFOX_FDROID_REPO_PATH='ironfox-oss/fdroid'

# fdroid-metadata repo
readonly IRONFOX_FDROID_METADATA="${IRONFOX_FDROID_REPO_ROOT}/fdroid/metadata"
readonly IRONFOX_FDROID_METADATA_BRANCH='main'

readonly IRONFOX_FDROID_METADATA_FILE_NAME='org.ironfoxoss.ironfox.yml'
readonly IRONFOX_FDROID_METADATA_FILE_PATH="${IRONFOX_FDROID_METADATA}/${IRONFOX_FDROID_METADATA_FILE_NAME}"

readonly IRONFOX_FDROID_METADATA_NIGHTLY_FILE_NAME='org.ironfoxoss.ironfox.nightly.yml'
readonly IRONFOX_FDROID_METADATA_NIGHTLY_FILE_PATH="${IRONFOX_FDROID_METADATA}/${IRONFOX_FDROID_METADATA_NIGHTLY_FILE_NAME}"

# Git
readonly IRONFOX_GIT_EMAIL='ci@ironfoxoss.org'
readonly IRONFOX_GIT_NAME='IronFox CI'
readonly IRONFOX_GIT_USERNAME='ironfox-ci'

# APK version
if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
  readonly IRONFOX_APK_VERSION="${IRONFOX_VERSION}"
else
  verify_env "${IRONFOX_NIGHTLY_TIMESTAMP_OVERRIDE}" 'IRONFOX_NIGHTLY_TIMESTAMP_OVERRIDE' || exit 1
  readonly IRONFOX_APK_VERSION="${IRONFOX_VERSION}.${IRONFOX_NIGHTLY_TIMESTAMP_OVERRIDE}"
fi

# Configure Git
function configure_git() {
  # Ensure we have a push token...
  verify_env "${IRONFOX_GITLAB_CI_PUSH_TOKEN}" 'IRONFOX_GITLAB_CI_PUSH_TOKEN' || return 1

  # Ensure we have `IRONFOX_GIT_EMAIL`
  verify_env "${IRONFOX_GIT_EMAIL}" 'IRONFOX_GIT_EMAIL' || return 1

  # Ensure we have `IRONFOX_GIT_NAME`
  verify_env "${IRONFOX_GIT_NAME}" 'IRONFOX_GIT_NAME' || return 1

  # Ensure we have `IRONFOX_GIT_USERNAME`
  verify_env "${IRONFOX_GIT_USERNAME}" 'IRONFOX_GIT_USERNAME' || return 1

  echo_red_text 'Configuring Git...'
  "${IRONFOX_GIT}" config --global user.email "${IRONFOX_GIT_EMAIL}" || return 1
  "${IRONFOX_GIT}" config --global user.name "${IRONFOX_GIT_NAME}" || return 1
  "${IRONFOX_GIT}" config --global url."https://${IRONFOX_GIT_USERNAME}:${IRONFOX_GITLAB_CI_PUSH_TOKEN}@gitlab.com/".insteadOf "https://gitlab.com/" || return 1
  echo_green_text 'SUCCESS: Configured Git.'
}

# Function to download an APK for a desired release
function download_release() {
  function print_usage() {
    echo "Usage: download_release 'version' 'architecture' 'path/to/output/dir'"
  }

  if [[ -z "${1+x}" ]]; then
    echo_red_text 'ERROR: Please specify the version to download!'
    print_usage
    return 1
  fi

  if [[ -z "${2+x}" ]]; then
    echo_red_text 'ERROR: Please specify the architecture to download!'
    print_usage
    return 1
  fi

  if [[ -z "${3+x}" ]]; then
    echo_red_text 'ERROR: Please specify the path to the output directory!'
    print_usage
    return 1
  fi

  # Ensure we have GNU awk
  verify_exec "${IRONFOX_AWK}" 'IRONFOX_AWK' || return 1

  # Ensure we have shasum
  verify_exec "${IRONFOX_SHASUM}" 'IRONFOX_SHASUM' || return 1

  local -r version="$1"
  local -r arch="$2"
  local -r output_dir="$3"

  if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
    local -r target_apk="ironfox-${version}-${arch}.apk"
  else
    local -r target_apk="ironfox-${IRONFOX_CHANNEL}-${version}-${arch}.apk"
  fi

  local -r target_expected_sha512sum="${target_apk}-sha512sum.txt"
  local -r target_expected_sha512sum_url="${IRONFOX_RELEASES_TARGET_URL}/${version}/${arch}/${target_expected_sha512sum}"
  local -r target_apk_url="${IRONFOX_RELEASES_TARGET_URL}/${version}/${arch}/${target_apk}"
  local -r output_apk="${output_dir}/${target_apk}"
  local -r output_expected_sha512sum="${output_dir}/${target_expected_sha512sum}"

  # Download the APK
  echo_red_text "Downloading ${target_apk} from ${target_apk_url}..."
  download "${target_apk_url}" "${output_apk}" || return 1
  echo_green_text "SUCCESS: Downloaded ${target_apk}"

  # Check the SHA512sum
  echo_red_text "Validating SHA512sum for file: '${target_apk}'..."
  download "${target_expected_sha512sum_url}" "${output_expected_sha512sum}" || return 1
  local -r expected_sha512sum=$("${IRONFOX_CAT}" "${output_expected_sha512sum}" | "${IRONFOX_XARGS}")
  local -r local_sha512sum=$("${IRONFOX_SHASUM}" -a 512 "${output_apk}" | "${IRONFOX_AWK}" '{print $1}')
  if [[ "${local_sha512sum}" != "${expected_sha512sum}" ]]; then
    echo_red_text "ERROR: Checksum validation for file failed: '${target_apk}'!"
    echo "Expected SHA512sum: '${expected_sha512sum}'"
    echo "Actual SHA512sum:   '${local_sha512sum}'"

    # If checksum validation fails, also just clean-up the files
    "${IRONFOX_RM}" -f "${output_apk}"
    "${IRONFOX_RM}" -f "${output_expected_sha512sum}"
    return 1
  fi
  echo_green_text "SUCCESS: Validated checksum for file: '${target_apk}'!"
  echo "SHA512sum: '${local_sha512sum}'"
}

# Function to download all APKs for a desired release
function download_releases() {
  # ARM64
  download_release "${IRONFOX_APK_VERSION}" 'arm64-v8a' "${IRONFOX_FDROID_REPO}" || return 1

  # ARM
  download_release "${IRONFOX_APK_VERSION}" 'armeabi-v7a' "${IRONFOX_FDROID_REPO}" || return 1

  # x86_64
  download_release "${IRONFOX_APK_VERSION}" 'x86_64' "${IRONFOX_FDROID_REPO}" || return 1
}

# Configure Git
configure_git || exit 1

# Clone the repo
clone_git_repo "https://${IRONFOX_GIT_USERNAME}:${IRONFOX_GITLAB_CI_PUSH_TOKEN}@gitlab.com/${IRONFOX_FDROID_REPO_PATH}.git" "${IRONFOX_FDROID_REPO_ROOT}" 'no-revision' --silent --submodules || exit 1
pushd "${IRONFOX_FDROID_REPO_ROOT}" || {
  echo_red_text "ERROR: Unable to pushd into '${IRONFOX_FDROID_REPO_ROOT}'"
  exit 1
}
"${IRONFOX_MKDIR}" -vp "${IRONFOX_FDROID_REPO}"
"${IRONFOX_GIT}" lfs install || exit 1

# Download all variants of the latest release
download_releases || exit 1

# Because we now upload releases to releases.ironfoxoss.org, the F-Droid repo doesn't need to store them all anymore
# So to improve performance and reduce size, we can keep only the last 3 releases
"${IRONFOX_MKDIR}" -p "${IRONFOX_TEMP}"

download "${IRONFOX_RELEASES_BASE_URL}/releases/previous_release.txt" "${IRONFOX_TEMP}/release_previous_release.txt" || exit 1
download "${IRONFOX_RELEASES_BASE_URL}/releases/previous_previous_release.txt" "${IRONFOX_TEMP}/release_previous_previous_release.txt" || exit 1

download "${IRONFOX_RELEASES_BASE_URL}/nightly/previous_release.txt" "${IRONFOX_TEMP}/nightly_previous_release.txt" || exit 1
download "${IRONFOX_RELEASES_BASE_URL}/nightly/previous_previous_release.txt" "${IRONFOX_TEMP}/nightly_previous_previous_release.txt" || exit 1

# If we're targetting Release, we also need to get the current Nightly version
if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
  download "${IRONFOX_RELEASES_BASE_URL}/nightly/latest_release.txt" "${IRONFOX_TEMP}/nightly_latest_release.txt" || exit 1
  readonly IRONFOX_NIGHTLY_VERSION=$("${IRONFOX_CAT}" "${IRONFOX_TEMP}/nightly_latest_release.txt" | "${IRONFOX_XARGS}")
else
  readonly IRONFOX_NIGHTLY_VERSION="${IRONFOX_APK_VERSION}"
fi

readonly release_previous_version=$("${IRONFOX_CAT}" "${IRONFOX_TEMP}/release_previous_release.txt" | "${IRONFOX_XARGS}")
readonly release_previous_previous_version=$("${IRONFOX_CAT}" "${IRONFOX_TEMP}/release_previous_previous_release.txt" | "${IRONFOX_XARGS}")

readonly nightly_previous_version=$("${IRONFOX_CAT}" "${IRONFOX_TEMP}/nightly_previous_release.txt" | "${IRONFOX_XARGS}")
readonly nightly_previous_previous_version=$("${IRONFOX_CAT}" "${IRONFOX_TEMP}/nightly_previous_previous_release.txt" | "${IRONFOX_XARGS}")

readonly release_current_apk_arm64="ironfox-${IRONFOX_VERSION}-arm64-v8a.apk"
readonly release_previous_apk_arm64="ironfox-${release_previous_version}-arm64-v8a.apk"
readonly release_previous_previous_apk_arm64="ironfox-${release_previous_previous_version}-arm64-v8a.apk"
readonly release_current_apk_arm64_sha512sum="${release_current_apk_arm64}-sha512sum.txt"
readonly release_previous_apk_arm64_sha512sum="${release_previous_apk_arm64}-sha512sum.txt"
readonly release_previous_previous_apk_arm64_sha512sum="${release_previous_previous_apk_arm64}-sha512sum.txt"

readonly nightly_current_apk_arm64="ironfox-nightly-${IRONFOX_NIGHTLY_VERSION}-arm64-v8a.apk"
readonly nightly_previous_apk_arm64="ironfox-nightly-${nightly_previous_version}-arm64-v8a.apk"
readonly nightly_previous_previous_apk_arm64="ironfox-nightly-${nightly_previous_previous_version}-arm64-v8a.apk"
readonly nightly_current_apk_arm64_sha512sum="${nightly_current_apk_arm64}-sha512sum.txt"
readonly nightly_previous_apk_arm64_sha512sum="${nightly_previous_apk_arm64}-sha512sum.txt"
readonly nightly_previous_previous_apk_arm64_sha512sum="${nightly_previous_previous_apk_arm64}-sha512sum.txt"

readonly release_current_apk_arm="ironfox-${IRONFOX_VERSION}-armeabi-v7a.apk"
readonly release_previous_apk_arm="ironfox-${release_previous_version}-armeabi-v7a.apk"
readonly release_previous_previous_apk_arm="ironfox-${release_previous_previous_version}-armeabi-v7a.apk"
readonly release_current_apk_arm_sha512sum="${release_current_apk_arm}-sha512sum.txt"
readonly release_previous_apk_arm_sha512sum="${release_previous_apk_arm}-sha512sum.txt"
readonly release_previous_previous_apk_arm_sha512sum="${release_previous_previous_apk_arm}-sha512sum.txt"

readonly nightly_current_apk_arm="ironfox-nightly-${IRONFOX_NIGHTLY_VERSION}-armeabi-v7a.apk"
readonly nightly_previous_apk_arm="ironfox-nightly-${nightly_previous_version}-armeabi-v7a.apk"
readonly nightly_previous_previous_apk_arm="ironfox-nightly-${nightly_previous_previous_version}-armeabi-v7a.apk"
readonly nightly_current_apk_arm_sha512sum="${nightly_current_apk_arm}-sha512sum.txt"
readonly nightly_previous_apk_arm_sha512sum="${nightly_previous_apk_arm}-sha512sum.txt"
readonly nightly_previous_previous_apk_arm_sha512sum="${nightly_previous_previous_apk_arm}-sha512sum.txt"

readonly release_current_apk_x86_64="ironfox-${IRONFOX_VERSION}-x86_64.apk"
readonly release_previous_apk_x86_64="ironfox-${release_previous_version}-x86_64.apk"
readonly release_previous_previous_apk_x86_64="ironfox-${release_previous_previous_version}-x86_64.apk"
readonly release_current_apk_x86_64_sha512sum="${release_current_apk_x86_64}-sha512sum.txt"
readonly release_previous_apk_x86_64_sha512sum="${release_previous_apk_x86_64}-sha512sum.txt"
readonly release_previous_previous_apk_x86_64_sha512sum="${release_previous_previous_apk_x86_64}-sha512sum.txt"

readonly nightly_current_apk_x86_64="ironfox-nightly-${IRONFOX_NIGHTLY_VERSION}-x86_64.apk"
readonly nightly_previous_apk_x86_64="ironfox-nightly-${nightly_previous_version}-x86_64.apk"
readonly nightly_previous_previous_apk_x86_64="ironfox-nightly-${nightly_previous_previous_version}-x86_64.apk"
readonly nightly_current_apk_x86_64_sha512sum="${nightly_current_apk_x86_64}-sha512sum.txt"
readonly nightly_previous_apk_x86_64_sha512sum="${nightly_previous_apk_x86_64}-sha512sum.txt"
readonly nightly_previous_previous_apk_x86_64_sha512sum="${nightly_previous_previous_apk_x86_64}-sha512sum.txt"

for apk in "${IRONFOX_FDROID_REPO}"/*.apk; do
  apk_basename=$("${IRONFOX_BASENAME}" "${apk}")
  if [[ "${apk_basename}" != "${release_current_apk_arm64}" ]] && [[ "${apk_basename}" != "${release_previous_apk_arm64}" ]] &&
    [[ "${apk_basename}" != "${release_previous_previous_apk_arm64}" ]] && [[ "${apk_basename}" != "${release_current_apk_arm}" ]] &&
    [[ "${apk_basename}" != "${release_previous_apk_arm}" ]] && [[ "${apk_basename}" != "${release_previous_previous_apk_arm}" ]] &&
    [[ "${apk_basename}" != "${release_current_apk_x86_64}" ]] && [[ "${apk_basename}" != "${release_previous_apk_x86_64}" ]] &&
    [[ "${apk_basename}" != "${release_previous_previous_apk_x86_64}" ]] && [[ "${apk_basename}" != "${nightly_current_apk_arm64}" ]] &&
    [[ "${apk_basename}" != "${nightly_previous_apk_arm64}" ]] && [[ "${apk_basename}" != "${nightly_previous_previous_apk_arm64}" ]] &&
    [[ "${apk_basename}" != "${nightly_current_apk_arm}" ]] && [[ "${apk_basename}" != "${nightly_previous_apk_arm}" ]] &&
    [[ "${apk_basename}" != "${nightly_previous_previous_apk_arm}" ]] && [[ "${apk_basename}" != "${nightly_current_apk_x86_64}" ]] &&
    [[ "${apk_basename}" != "${nightly_previous_apk_x86_64}" ]] && [[ "${apk_basename}" != "${nightly_previous_previous_apk_x86_64}" ]]; then
    "${IRONFOX_RM}" -vf "${apk}"
  fi
done

for sha_txt in "${IRONFOX_FDROID_REPO}"/*-sha512sum.txt; do
  sha_basename=$("${IRONFOX_BASENAME}" "${sha_txt}")
  if [[ "${sha_basename}" != "${release_current_apk_arm64_sha512sum}" ]] && [[ "${sha_basename}" != "${release_previous_apk_arm64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${release_previous_previous_apk_arm64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${release_current_apk_arm_sha512sum}" ]] && [[ "${sha_basename}" != "${release_previous_apk_arm_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${release_previous_previous_apk_arm_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${release_current_apk_x86_64_sha512sum}" ]] && [[ "${sha_basename}" != "${release_previous_apk_x86_64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${release_previous_previous_apk_x86_64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_current_apk_arm64_sha512sum}" ]] && [[ "${sha_basename}" != "${nightly_previous_apk_arm64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_previous_previous_apk_arm64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_current_apk_arm_sha512sum}" ]] && [[ "${sha_basename}" != "${nightly_previous_apk_arm_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_previous_previous_apk_arm_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_current_apk_x86_64_sha512sum}" ]] && [[ "${sha_basename}" != "${nightly_previous_apk_x86_64_sha512sum}" ]] &&
    [[ "${sha_basename}" != "${nightly_previous_previous_apk_x86_64_sha512sum}" ]]; then
    "${IRONFOX_RM}" -vf "${sha_txt}"
  fi
done

source "${IRONFOX_PYENV}" || exit 1
IFS=":" read -r vercode vername <<< "$("${IRONFOX_PYTHON}" "${IRONFOX_SCRIPTS}/get_latest_version.py" $("${IRONFOX_LS}" "${IRONFOX_FDROID_REPO}"/*.apk))" || exit 1

if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
  readonly if_fdroid_metadata_file="${IRONFOX_FDROID_METADATA_FILE_PATH}"
else
  readonly if_fdroid_metadata_file="${IRONFOX_FDROID_METADATA_NIGHTLY_FILE_PATH}"
fi

"${IRONFOX_SED}" -i \
  -e "s/CurrentVersion: .*/CurrentVersion: \"v${vername}\"/" \
  -e "s/CurrentVersionCode: .*/CurrentVersionCode: ${vercode}/" "${if_fdroid_metadata_file}" || exit 1

pushd "${IRONFOX_FDROID_METADATA}" || {
  echo_red_text "ERROR: Unable to pushd into '${IRONFOX_FDROID_METADATA}'"
  exit 1
}

# Update metadata repository
"${IRONFOX_GIT}" add "${IRONFOX_FDROID_METADATA_FILE_NAME}" "${IRONFOX_FDROID_METADATA_NIGHTLY_FILE_NAME}" || exit 1
"${IRONFOX_GIT}" commit -m "feat: update for IronFox ${IRONFOX_CHANNEL}: ${IRONFOX_APK_VERSION}" || echo 'Metadata repo already up to date! Not committing anything...'
"${IRONFOX_GIT}" push origin "HEAD:${IRONFOX_FDROID_METADATA_BRANCH}" || echo 'Metadata repo already up to date! Not pushing anything...'

popd || {
  echo_red_text "ERROR: Unable to popd from '${IRONFOX_FDROID_METADATA}'"
  exit 1
}

# Indicate our target release channel (so that `ci-update-git.repo.sh` can handle it properly...)
"${IRONFOX_RM}" -f "${IRONFOX_FDROID_REPO_ROOT}/target-release" "${IRONFOX_FDROID_REPO_ROOT}/target-nightly" || exit 1
if [[ "${IRONFOX_RELEASE}" == 1 ]]; then
  "${IRONFOX_TOUCH}" "${IRONFOX_FDROID_REPO_ROOT}/target-release" || exit 1
  "${IRONFOX_GIT}" add "${IRONFOX_FDROID_REPO_ROOT}/target-release" || exit 1
else
  "${IRONFOX_TOUCH}" "${IRONFOX_FDROID_REPO_ROOT}/target-nightly" || exit 1
  "${IRONFOX_GIT}" add "${IRONFOX_FDROID_REPO_ROOT}/target-nightly" || exit 1
fi

# Update F-Droid repository
"${IRONFOX_GIT}" add "${IRONFOX_FDROID_REPO}" "${IRONFOX_FDROID_METADATA}" || exit 1
"${IRONFOX_GIT}" commit -m "feat: update for IronFox ${IRONFOX_CHANNEL}: ${IRONFOX_APK_VERSION}" || exit 1
"${IRONFOX_GIT}" push origin "HEAD:${IRONFOX_FDROID_REPO_BRANCH}" || exit 1

popd || exit 1
